
#1.HG00267
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00267/exome_alignment/HG00267.chrom11.ILLUMINA.bwa.FIN.exome.20130415.bam

#2.HG00268
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00268/exome_alignment/HG00268.chrom11.ILLUMINA.bwa.FIN.exome.20121211.bam

#3.HG00269
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00269/exome_alignment/HG00269.chrom11.ILLUMINA.bwa.FIN.exome.20130415.bam

#4.HG00271
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00271/exome_alignment/HG00271.chrom11.ILLUMINA.bwa.FIN.exome.20121211.bam

#5.HG00272
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00272/exome_alignment/HG00272.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#6.HG00273
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00273/exome_alignment/HG00273.chrom11.ILLUMINA.bwa.FIN.exome.20121211.bam

#7.HG00274
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00274/exome_alignment/HG00274.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#8.HG00275
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00275/exome_alignment/HG00275.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#9.HG00276
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00276/exome_alignment/HG00276.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#10.HG00277
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00277/exome_alignment/HG00277.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#11.HG00278
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00278/exome_alignment/HG00278.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#12.HG00280
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00280/exome_alignment/HG00280.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#13.HG00281
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00281/exome_alignment/HG00281.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#14.HG00282
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00282/exome_alignment/HG00282.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#15.HG00284
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00284/exome_alignment/HG00284.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#16.HG00285
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00285/exome_alignment/HG00285.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

#17.HG00288
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00288/exome_alignment/HG00288.chrom11.ILLUMINA.bwa.FIN.exome.20130415.bam

#18.HG00290
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00290/exome_alignment/HG00290.chrom11.ILLUMINA.bwa.FIN.exome.20130415.bam

#19.HG00304
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00304/exome_alignment/HG00304.chrom11.ILLUMINA.bwa.FIN.exome.20130415.bam

#20.HG00306
wget https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/phase3/data/HG00306/exome_alignment/HG00306.chrom11.ILLUMINA.bwa.FIN.exome.20120522.bam

