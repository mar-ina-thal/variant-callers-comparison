/home/marina/Documents/opt/gatk-4.4.0.0/gatk GenotypeGVCFs \
-R chromosome11.fasta \
-V gendb://my_database \
-G StandardAnnotation \
-O test_output.vcf
