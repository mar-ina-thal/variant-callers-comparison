for i in {267..306}; do
 samtools index HG00$i.nodup.bam
done
