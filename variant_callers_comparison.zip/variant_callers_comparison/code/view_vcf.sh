bcftools query -f '%CHROM\t%POS\t%ID\t%REF\t%ALT\t%QUAL\t%FILTER\t%INFO\n' /media/marina/marina2TB/strelka2/demo_germline/results/variants/variants.vcf.gz
